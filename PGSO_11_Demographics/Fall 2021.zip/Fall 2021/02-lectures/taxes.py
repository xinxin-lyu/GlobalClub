def in_tax(p):
    """Function to calculate Indiana sales tax"""
    taxes = p * 0.07  # sales tax in Indiana is 7%
    return taxes


def ky_tax(p):
    """Function that calculates Kentucky tax amount (6%) on sale at price p"""
    taxes = p * 0.06  # Kentuky state sales tax rate is 6%
    return taxes
